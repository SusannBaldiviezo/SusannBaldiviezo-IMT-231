#!/bin/bash
read -p "Ingrese el nombre del usuario:" nombre
echo "Hola $nombre, Bienvenido"
cat script.sh 

