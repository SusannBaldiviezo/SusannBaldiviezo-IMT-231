#!/bin/bash
#PRACTICA DE COMANDOS SHELL
#Directorio actual
pwd
#ACCEDER A CARPETA /tmp y listar su contenido
cd /tmp 
ls
#VOLVER AL DIRECTORIO PERSONAL
cd ~
#EN EL DIRECTORIO CREAR UNA CARPETA
mkdir practica_shell
#ACCEDER A LA CARPETA
cd ./practica_shell
#MOSTRA EL DIRECTORIO ACTUAL
pwd


